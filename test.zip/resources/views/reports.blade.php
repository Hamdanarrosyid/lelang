<x-layouts.dashboard title="Generate Reports" headerTitle="Generate Reports" reports="active">
    @section('content')

    @endsection
</x-layouts.dashboard>
