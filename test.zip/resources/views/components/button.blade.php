<button type="{{$type??'button'}}" class="{{$bg}} focus:outline-none my-1 hover:bg-opacity-70 cursor-pointer {{$color??'text-black'}} px-4 py-1 rounded-md">{{$title}}</button>
