<a href="{{$href ?? '#'}}" class="focus:outline-none hover:bg-opacity-70 {{$bg}} cursor-pointer px-4 py-1.5 my-1 rounded-md {{$color??'text-black'}} ">{{$title}}</a>
