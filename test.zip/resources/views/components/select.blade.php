<select class="w-full shadow-lg bg-gray-300 outline-none p-2 my-3" name="{{$name}}" id="goods">
    {{$slot}}
</select>
