<x-layouts.bidding title="Bidding">
    @section('content')
        <div class="w-10/12">

        </div>
    @endsection
</x-layouts.bidding>
